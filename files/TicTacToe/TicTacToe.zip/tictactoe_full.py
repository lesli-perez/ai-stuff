# ============================================================
#  TIC TAC TOE — Full Version
#  Intro to CS | Instructor Reference Copy
# ============================================================

def create_board():
    """Returns a fresh 3x3 board as a list of lists filled with spaces."""
    board = []

    for _ in range(3):
        row = []
        for _ in range(3):
            row.append(" ")
        board.append(row)

    return board


def display_board(board):
    """Prints the board with row/column separators."""
    print()
    for i in range(3):
        row = board[i]
        print("  " + " | ".join(row))
        if i < 2:
            print("  " + "-" * 9)
    print()


def get_player_move(board, player):
    """
    Asks the current player for a row and column.
    Keeps asking until they enter a valid, empty cell.
    Returns (row, col) as a tuple.
    """
    while True:
        try:
            row_prompt = f"  Player {player} — enter row    (1, 2, or 3): "
            row_text = input(row_prompt)
            row = int(row_text) - 1

            col_prompt = f"  Player {player} — enter column (1, 2, or 3): "
            col_text = input(col_prompt)
            col = int(col_text) - 1

            if (row < 0 or row > 2) or (col < 0 or col > 2):
                print("  ⚠  Out of range! Please enter a number between 1 and 3.\n")
            elif board[row][col] != " ":
                print("  ⚠  That cell is already taken! Try again.\n")
            else:
                return row, col

        except ValueError:
            print("  ⚠  Invalid input! Please enter a number.\n")


def place_marker(board, row, col, marker):
    """Places the player's marker ('X' or 'O') on the board."""
    board[row][col] = marker


def check_winner(board, marker):
    """
    Returns True if the given marker has won the game.
    Checks all rows, columns, and both diagonals.
    """
    # Check rows
    for row in board:
        row_win = True
        for cell in row:
            if cell != marker:
                row_win = False
                break
        if row_win:
            return True

    # Check columns
    for col in range(3):
        col_win = True
        for row in range(3):
            if board[row][col] != marker:
                col_win = False
                break
        if col_win:
            return True

    # Check main diagonal (top-left to bottom-right)
    diagonal_win = True
    for i in range(3):
        if board[i][i] != marker:
            diagonal_win = False
            break
    if diagonal_win:
        return True

    # Check anti-diagonal (top-right to bottom-left)
    diagonal_win = True
    for i in range(3):
        if board[i][2 - i] != marker:
            diagonal_win = False
            break
    if diagonal_win:
        return True

    return False


def check_draw(board):
    """Returns True if every cell is filled and no one has won yet."""
    for row in range(3):
        for col in range(3):
            if board[row][col] == " ":
                return False

    return True


def play_game():
    """Main game loop — runs one full game of Tic Tac Toe."""
    board   = create_board()
    current_player = "X"

    print("\n" + "=" * 40)
    print("       Welcome to Tic Tac Toe! 🎮")
    print("=" * 40)

    while True:
        display_board(board)
        print(f"  ── Player {current_player}'s turn ──")

        row, col = get_player_move(board, current_player)
        place_marker(board, row, col, current_player)

        if check_winner(board, current_player):
            display_board(board)
            print(f"  🏆  Player {current_player} wins! Congratulations!\n")
            break

        if check_draw(board):
            display_board(board)
            print("  🤝  It's a draw! Well played by both!\n")
            break

        # Switch to the other player
        if current_player == "X":
            current_player = "O"
        else:
            current_player = "X"

    again = input("  Play again? (yes / no): ").strip().lower()
    if again in ("yes", "y"):
        play_game()
    else:
        print("\n  Thanks for playing! Goodbye 👋\n")


# ── Entry point ──────────────────────────────────────────────
if __name__ == "__main__":
    play_game()
