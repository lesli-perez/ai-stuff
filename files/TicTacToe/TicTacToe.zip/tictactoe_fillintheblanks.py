# ============================================================
#  TIC TAC TOE — Fill-in-the-Blank Version
#  Intro to CS | Student Practice Copy
#
#  Instructions:
#    Replace every  ___  with the correct code.
#    Some sections are already written for you — study them!
#    Run the file after each section to test your work.
# ============================================================


def create_board():
    """
    TODO #1 — Create the board
    ─────────────────────────────────────────────────────────
    A Tic Tac Toe board is a 3x3 grid.
    We represent it as a list of 3 rows.
    Each row is a list of 3 spaces: " "

    Fill in the blank so this function returns:
        [ [" ", " ", " "],
          [" ", " ", " "],
          [" ", " ", " "] ]
    """
    board = []

    for _ in range(3):
        row = []
        for _ in range(3):
            row.append(___)
            #         ^^^
            #         What should each empty cell contain?
        board.append(row)

    return board


def display_board(board):
    """Prints the board — already done for you, study it!"""
    print()
    for i, row in enumerate(board):
        print("  " + " | ".join(row))
        if i < 2:
            print("  " + "-" * 9)
    print()


def get_player_move(board, player):
    """
    TODO #2 — Validate the player's move
    ─────────────────────────────────────────────────────────
    We already ask for input and convert it to 0-based index.
    You need to fill in the THREE checks inside the if/elif/else:

      Check A: Is the row or column out of range (not 0, 1, or 2)?
      Check B: Is the chosen cell already taken (not a space)?
      Check C (else): The move is valid — return it!
    """
    while True:
        try:
            row_prompt = f"  Player {player} — enter row    (1, 2, or 3): "
            row_text = input(row_prompt)
            row = int(row_text) - 1

            col_prompt = f"  Player {player} — enter column (1, 2, or 3): "
            col_text = input(col_prompt)
            col = int(col_text) - 1

            # Check A — out of range?
            if (___ < 0 or ___ > 2) or (___ < 0 or ___ > 2):
            #   ^^^     ^^^            ^^^     ^^^
            #   use row for the first pair, col for the second pair
                print("  ⚠  Out of range! Please enter a number between 1 and 3.\n")

            # Check B — cell already taken?
            elif board[___][___] != " ":
            #         ^^^  ^^^
            #         use row and col to look up the cell
                print("  ⚠  That cell is already taken! Try again.\n")

            # Check C — valid move!
            else:
                return ___, ___
                #      ^^^  ^^^
                #      return the two values we need

        except ValueError:
            print("  ⚠  Invalid input! Please enter a number.\n")


def place_marker(board, row, col, marker):
    """
    TODO #3 — Place the marker
    ─────────────────────────────────────────────────────────
    One line: put the marker into the correct spot on the board.
    Hint: board is a 2D list — you need TWO indexes.
    """
    ___[___][___] = ___
    # ^board ^row  ^col  ^marker


def check_winner(board, marker):
    """
    TODO #4 — Check for a winner
    ─────────────────────────────────────────────────────────
    A player wins if their marker fills an entire:
      • Row       (left → right)
      • Column    (top → bottom)
      • Diagonal  (corner → corner)

    Fill in the blanks for rows and columns.
    The diagonals are already done — study the pattern!
    """

    # --- Rows ---
    for row in board:
        if all(cell == ___ for cell in row):
            #              ^^^
            #              what are we checking each cell against?
            return True

    # --- Columns ---
    for col in range(3):
        if all(board[___][col] == marker for ___ in range(3)):
            #        ^^^                      ^^^
            #        same variable — what iterates over rows?
            return True

    # --- Main diagonal (top-left → bottom-right) --- already written!
    if all(board[i][i] == marker for i in range(3)):
        return True

    # --- Anti-diagonal (top-right → bottom-left) --- already written!
    if all(board[i][2 - i] == marker for i in range(3)):
        return True

    return False


def check_draw(board):
    """
    TODO #5 — Check for a draw
    ─────────────────────────────────────────────────────────
    The game is a draw if every cell is filled (no spaces left).
    Fill in the blank: what should we check each cell against?
    """
    for row in range(3):
        for col in range(3):
            if board[row][col] == ___:
                #                   ^^^
                #                   what does an EMPTY cell contain?
                return False

    return True


def play_game():
    """Main game loop — already written for you! Read through it carefully."""
    board   = create_board()
    players = ["X", "O"]
    turn    = 0

    print("\n" + "=" * 40)
    print("       Welcome to Tic Tac Toe! 🎮")
    print("=" * 40)

    while True:
        current_player = players[turn % 2]   # 0%2=0 → X, 1%2=1 → O, 2%2=0 → X …

        display_board(board)
        print(f"  ── Player {current_player}'s turn ──")

        row, col = get_player_move(board, current_player)
        place_marker(board, row, col, current_player)

        if check_winner(board, current_player):
            display_board(board)
            print(f"  🏆  Player {current_player} wins! Congratulations!\n")
            break

        if check_draw(board):
            display_board(board)
            print("  🤝  It's a draw! Well played by both!\n")
            break

        turn += 1

    again = input("  Play again? (yes / no): ").strip().lower()
    if again in ("yes", "y"):
        play_game()
    else:
        print("\n  Thanks for playing! Goodbye 👋\n")


# ── Entry point ──────────────────────────────────────────────
if __name__ == "__main__":
    play_game()
