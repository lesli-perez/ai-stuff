/*
Mr. Alfredo Ramos
Description:
This program is used to create randomized problems for assign1: decimal, binary, 
hexadecimal conversion and create a file with the problems. You can then use the
text file output to copy the problems to the problem handout given to students.

Future Work:
Currently the program is bunched up into one file and perhaps will make changes
to make it more efficient to produce problems for assign2 and assign3 by doing
the following changes:
- Separate the decimal, binary, hexadecimal problem generator so that strings 
	can be used in multiple assignments.
- Create a separate .cpp/.h file to produce the answers for the generated problems
	which may be on a assignment bases. (should help automate the workload)
*/


#include <iostream>
#include <string>
#include <time.h>
#include <iomanip>
#include <fstream>

using namespace std;

// function to convert and integer between
// 0 and 15 into hexadecimal repersentation
string HexDigitRep(int);

// Function to reverse binary string
string ReverseBinary(string);

/*	
	function prototypes for creating binary problems,
	decimal problems, and hexadecimal problems.
*/
void CreateBinaryProblem(string, char, const int, const int, ofstream&);
void CreateDecimalProblem(string, char, const int, const int, ofstream&);
void CreateHexadecimalProblem(string, char, const int, const int, ofstream&);

// function to display the grading criteria
void DisplayGradingCriteria(ofstream&);

// const varaible to hold setw size
const int setw_size = 17;

int main()
{
	// variables to hold data:
	string base_str = "";
	char p_num = 'a';

	// variable for file manipulation
	ofstream outfile;

	// constant variables to change the # problems
	const int NUM_OF_SUB_PROB = 5;

	// constant variables to hold the base modulus
	const int BIN_MOD = 2;
	const int DECI_MOD = 10;
	const int HEX_MOD = 16;

	// random seed initializer with time
	srand(time(NULL));

	// open the file that will hold the problems
	outfile.open("1101assgn1P.txt");

	// Problem 1
	cout << "1. Convert the following binary (base 2) "
		<< "numbers to decimal (base 10) values." << endl << endl;
	outfile << "1. Convert the following binary (base 2) "
		<< "numbers to decimal (base 10) values." << endl << endl;

	// call function to create the problems for binary
	CreateBinaryProblem(base_str, p_num, NUM_OF_SUB_PROB, BIN_MOD, outfile);

	// reset the string
	base_str = "";

	// add a space to console
	cout << endl;
	// add a space to file
	outfile << endl;
	
	//---------------------------------------------------------------------------------------

	// Problem 2
	cout << "2. Convert the following decimal (base 10) "
		<< "numbers to binary (base 2) values." << endl << endl;
	outfile << "2. Convert the following decimal (base 10) "
		<< "numbers to binary (base 2) values." << endl << endl;
	
	// call function to creat problems for deciaml
	CreateDecimalProblem(base_str, p_num, NUM_OF_SUB_PROB, DECI_MOD, outfile);
	
	// reset the string
	base_str = "";

	// add a space to console
	cout << endl;
	// add a space to file
	outfile << endl;

	//---------------------------------------------------------------------------------------

	// Problem 3
	cout << "3. Convert the following Hexadecimal (base 16) "
		<< "numbers to binary (base 2) values" << endl << endl;
	outfile << "3. Convert the following Hexadecimal (base 16) "
		<< "numbers to binary (base 2) values" << endl << endl;

	// call function to creat problems for hexadecimal
	CreateHexadecimalProblem(base_str, p_num, NUM_OF_SUB_PROB, HEX_MOD, outfile);

	// reset the string
	base_str = "";

	// add a space to console
	cout << endl;
	// add a space to file
	outfile << endl;

	//---------------------------------------------------------------------------------------

	// Problem 4
	cout << "4. Convert the following binary (base 2) "
		<< "numbers to hexadecimal (base 16) values" << endl << endl;
	outfile << "4. Convert the following binary (base 2) "
		<< "numbers to hexadecimal (base 16) values" << endl << endl;

	// call function to creat problems for hexadecimal
	CreateBinaryProblem(base_str, p_num, NUM_OF_SUB_PROB, BIN_MOD, outfile);

	// reset the string
	base_str = "";

	// add a space to console
	cout << endl;
	// add a space to file
	outfile << endl;

	//---------------------------------------------------------------------------------------

	// Problem 5
	cout << "5. Convert the following decimal (base 10) "
		<< "numbers to hexadecimal (base 16) values" << endl << endl;
	outfile << "5. Convert the following decimal (base 10) "
		<< "numbers to hexadecimal (base 16) values" << endl << endl;

	// call function to creat problems for hexadecimal
	CreateDecimalProblem(base_str, p_num, NUM_OF_SUB_PROB, DECI_MOD, outfile);

	// reset the string
	base_str = "";

	// add a space to console
	cout << endl;
	// add a space to file
	outfile << endl;

	//---------------------------------------------------------------------------------------

	// Problem 6
	cout << "6. Convert the following Hexadecimal (base 16) "
		<< "numbers to decimal (base 10) values" << endl << endl;
	outfile << "6. Convert the following Hexadecimal (base 16) "
		<< "numbers to decimal (base 10) values" << endl << endl;

	// call function to creat problems for hexadecimal
	CreateHexadecimalProblem(base_str, p_num, NUM_OF_SUB_PROB, HEX_MOD, outfile);

	// add an extra space to console
	cout << endl;

	// add an extra space to file
	outfile << endl;

	//call function to create grading criteria
	DisplayGradingCriteria(outfile);

	//close the file
	outfile.close();
	
	return 0;
}

/*
	Function definition used to display the grading criteria
*/
void DisplayGradingCriteria(ofstream& out)
{
	// print to console
	cout << "Grading Criteria" << endl;
	cout << "1. There is no answer nor work shown for the "
		<< "question: - 8 points" << endl;
	cout << "2. Answer is incorrect, work is correct: -2 points" << endl;
	cout << "3. Answer is correct, work is incorrect: -2 points" << endl;
	cout << "4. Answer is incorrect, work is incorrect: -3 points" << endl;
	cout << "5. Answer is correct, no work: -4 points" << endl;

	// print to file
	out << "Grading Criteria" << endl;
	out << "1. There is no answer nor work shown for the "
		<< "question: - 8 points" << endl;
	out << "2. Answer is incorrect, work is correct: -2 points" << endl;
	out << "3. Answer is correct, work is incorrect: -2 points" << endl;
	out << "4. Answer is incorrect, work is incorrect: -3 points" << endl;
	out << "5. Answer is correct, no work: -4 points" << endl;
}

/*
	Function used to return a hex digit to the function
	CreateHexadecimalProblem().
*/
string HexDigitRep(int hex_value)
{

	string hexadecimal = "";
	switch (hex_value)
	{
	case 15:
		hexadecimal = "F";
		break;
	case 14:
		hexadecimal = "E";
		break;
	case 13:
		hexadecimal = "D";
		break;
	case 12:
		hexadecimal = "C";
		break;
	case 11:
		hexadecimal = "B";
		break;
	case 10:
		hexadecimal = "A";
		break;
	default:
		hexadecimal = to_string(hex_value);
	}

	return hexadecimal;
}

// Function Definition to reverse a binary string
string ReverseBinary(string orig_bin)
{
	// holds the reversed binary value
	string rev_bin = "";

	//loop to copy the binary string in reverse
	for (int i = (orig_bin.length() - 1); i >= 0; --i)
	{
		rev_bin += orig_bin[i];
	}

	// return the binary value in reverse
	return rev_bin;
}

/*
	Function definitions used to create the problems for 
	binary, decimal, and hexadecimal
*/
void CreateBinaryProblem(string binary_str, char current_problem, 
	const int total_sub_prob, const int binary_mod, ofstream& out)
{
	// hold the number of digits for each problem
	int num_of_digits = 0;

	// initialize the number of digits between 1 and 11
	num_of_digits = (rand() % 11) + 1;

	// initialize binary string
	binary_str = to_string(rand() % binary_mod);

	// loop to creat 5 problems for binary
	for (int i = 0; i < total_sub_prob; ++i)
	{
		for (int n = 1; n <= num_of_digits; ++n)
		{
			if (n != 0 && (n % 4) == 0)
			{
				binary_str += (" " + to_string(rand() % binary_mod));
			}
			else
			{
				binary_str += to_string(rand() % binary_mod);
			}

		}
		// display current problem to console
		cout << "\t" << current_problem << ". " << setw(setw_size)
			<< left << "("  + ReverseBinary(binary_str) + ")" << "\t\t\tANSWER:"
			<< endl;
		// display current problem to file
		out << "\t" << current_problem << ". " << setw(setw_size)
			<< left << "(" + ReverseBinary(binary_str) + ")" << "\t\t\tANSWER:"
			<< endl;

		// increment the sub problem count
		++current_problem;
		// re-initialize the binary string
		binary_str = to_string(rand() % binary_mod);

		// re- initialize the number of digits between 1 and 11
		num_of_digits = (rand() % 11) + 1;
	}

}
void CreateDecimalProblem(string decimal_str, char current_problem, 
	const int total_sub_prob, const int decimal_mod, ofstream& out)
{
	// hold the number of digits
	int num_of_digits = 0;
	
	// initialize the decimal string
	decimal_str = to_string(rand() % decimal_mod);

	// initialize the number of digits between 1 and 2
	num_of_digits = (rand() % 2) + 1;

	// reset sub_prob counter
	current_problem = 'a';

	for (int i = 0; i < total_sub_prob; ++i)
	{
		for (int n = 1; n <= num_of_digits; ++n)
		{
			decimal_str += to_string(rand() % decimal_mod);
		}
		// display current problem to console
		cout << "\t" << current_problem << ". " << setw(setw_size)
			<< left << "(" + decimal_str + ")" << "\t\t\tANSWER:"
			<< endl;

		// display current problem to file
		out << "\t" << current_problem << ". " << setw(setw_size)
			<< left << "(" + decimal_str + ")" << "\t\t\tANSWER:"
			<< endl;

		// increment the sub problem count
		++current_problem;
		// re-initialize the decimal string
		decimal_str = to_string(rand() % decimal_mod);
		// re-initialize the number of digits between 1 and 2
		num_of_digits = (rand() % 2) + 1;
	}
}
void CreateHexadecimalProblem(string hexa_str, char current_problem, 
	const int total_sub_prob, const int hexa_mod, ofstream& out)
{
	// hold the hex digit to convert as a letter
	// or keep as a number
	int hex_rand_value = 0;
	// hold the number of digits for hex
	int num_of_digits = 0;

	// initialize the hex string
	hex_rand_value = rand() % hexa_mod;
	
	// get the hex digit rep
	hexa_str = HexDigitRep(hex_rand_value);

	// initialize the number of digits between 1 and 2
	num_of_digits = (rand() % 2) + 1;
	// reset sub_prob counter
	current_problem = 'a';

	// format output for left justified
	cout.left;

	for (int i = 0; i < total_sub_prob; ++i)
	{
		for (int n = 1; n <= num_of_digits; ++n)
		{
			hex_rand_value = rand() % hexa_mod;
			hexa_str += HexDigitRep(hex_rand_value);
		}
		// display current problem to console
		cout << "\t" << current_problem << ". " << setw(setw_size)
			<< left << "(" + hexa_str + ")" << "\t\t\tANSWER:"
			<< endl;

		// display current problem to file
		out << "\t" << current_problem << ". " << setw(setw_size)
			<< left << "(" + hexa_str + ")" << "\t\t\tANSWER:"
			<< endl;

		// increment the sub problem count
		++current_problem;
		// re-initialize the hex string
		hex_rand_value = rand() % hexa_mod;
		hexa_str = HexDigitRep(hex_rand_value);

		// re-initialize the number of digits between 1 and 2
		num_of_digits = (rand() % 2) + 1;
	}

}